const express = require("express");
const mongoose = require("mongoose");
const app = express();
exports.app = app;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
//ODM - object data modelling , ORM- object relational mapping
app.use("/api/blogs",blogRoute)
app.use("/api/users",userRoute)
const Blogs = require("./model/blog");
const User = require("./model/user");
let blogRoute = require("./routes/blogroutes");
let userRoute=require("./routes/userroutes");
app.listen(4445, () => {
  console.log("server started");
});

mongoose
  .connect("mongodb://127.0.0.1:27017/g26db")
  .then(() => console.log("Connected"));
