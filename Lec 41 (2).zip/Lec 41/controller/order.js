const Orderbook = require('../service/order');
let ob = new Orderbook('BTCUSD'); // global object to maintain orderbook state

module.exports.postPlaceOrder = async (req, res) => {
	// to create a new order for user who placed an order
	const { side, type, price, quantity, user } = req.body;
	const response = ob.placeOrder(side, type, price, quantity, user);
	// if I create object here it will be a new object for every request
	// so to maintain the state of orderbook we create a global object
	console.log(response);
	// return response to client
	return res.json(response);
};