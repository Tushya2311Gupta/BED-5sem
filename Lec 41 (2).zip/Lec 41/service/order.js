class Orderbook {
  constructor(symbol) {
    this.symbol = symbol;
    this.buyOrders = [];
    this.sellOrders = [];
  }

  placeOrder(side, type, price, quantity, user) {
    const order = { side, type, price: Number(price), quantity: Number(quantity), user, timestamp: Date.now() };

    if (side === 'buy') {
      this.buyOrders.push(order);
      this.buyOrders.sort((a, b) => b.price - a.price || a.timestamp - b.timestamp);
    } else if (side === 'sell') {
      this.sellOrders.push(order);
      this.sellOrders.sort((a, b) => a.price - b.price || a.timestamp - b.timestamp);
    } else {
      return { error: 'Invalid order side' };
    }

    return { success: true, order, buyOrders: this.buyOrders.length, sellOrders: this.sellOrders.length };
  }
}

module.exports = Orderbook;