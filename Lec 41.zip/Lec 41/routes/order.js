const router = require('express').Router();
const { postPlaceOrder } = require('../controller/order');

router.post('/', postPlaceOrder);

module.exports = router;