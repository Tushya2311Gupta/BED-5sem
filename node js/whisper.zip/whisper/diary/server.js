const express = require('express');
const path = require('path');
const hbs = require('hbs');
const mongoose = require('mongoose');
const Entry = require('./models/Entry');

const app = express();
const port = 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/whisperDiary')
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Views
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
hbs.registerPartials(path.join(__dirname, 'views/partials'));
app.use(express.static(path.join(__dirname, 'public')));

// -------------------- Handlebars Routes --------------------
app.get('/', (req, res) => res.render('login', { title: 'Login' }));
app.get('/dairy', (req, res) => res.render('dairy', { title: 'New Entry' }));

app.get('/journal', async (req, res) => {
  try {
    const entries = await Entry.find().sort({ createdAt: -1 });
    res.render('journal', { title: 'Journal', entries });
  } catch (err) {
    res.status(500).send('Error loading journal');
  }
});

app.get('/edit/:id', async (req, res) => {
  try {
    const entry = await Entry.findById(req.params.id);
    res.render('edit', { title: 'Edit Entry', entry });
  } catch {
    res.status(404).send('Entry not found');
  }
});

// -------------------- RESTful API Routes --------------------

// Get all entries
app.get('/api/entries', async (req, res) => {
  const entries = await Entry.find().sort({ createdAt: -1 });
  res.json(entries);
});

// Get a specific entry
app.get('/api/entries/:id', async (req, res) => {
  try {
    const entry = await Entry.findById(req.params.id);
    if (!entry) return res.status(404).json({ error: 'Not found' });
    res.json(entry);
  } catch {
    res.status(400).json({ error: 'Invalid ID' });
  }
});

// Create new entry
app.post('/api/entries', async (req, res) => {
  const { content } = req.body;
  if (!content) return res.status(400).json({ error: 'Content required' });
  const entry = new Entry({ content });
  await entry.save();
  res.status(201).json(entry);
});

// Update an entry
app.put('/api/entries/:id', async (req, res) => {
  try {
    const { content } = req.body;
    const entry = await Entry.findByIdAndUpdate(
      req.params.id,
      { content },
      { new: true }
    );
    if (!entry) return res.status(404).json({ error: 'Not found' });
    res.json(entry);
  } catch {
    res.status(400).json({ error: 'Invalid ID or input' });
  }
});

// Delete an entry
app.delete('/api/entries/:id', async (req, res) => {
  try {
    const result = await Entry.findByIdAndDelete(req.params.id);
    if (!result) return res.status(404).json({ error: 'Not found' });
    res.status(204).send();
  } catch {
    res.status(400).json({ error: 'Invalid ID' });
  }
});

// Fallback
app.use((req, res) => res.status(404).send('Not found'));

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
